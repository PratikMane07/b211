package com.cjc.springbootdemoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootdemoappApplicationTests {

	@Test
	void contextLoads() {
	}

}
